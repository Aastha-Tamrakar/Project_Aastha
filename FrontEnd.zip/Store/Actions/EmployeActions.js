import axios from "@/utils/axios";
import { addemploye,removeemploye,addtasks,iserror,removeerror } from "../Reducers/EmployeReducer";

export const asynccurrentemploye = () => async(dispatch,getstate) =>{
    try {
        const { data } = await axios.post("/employe/")
        dispatch(addemploye(data))
        // console.log("employe",data.employe)
        // console.log(data)
    } catch (error) {
        dispatch(iserror(error.response.data.message))
    }
}


export const asyncsignupemploye = (employe) => async(dispatch,getstate) =>{
        try {
            const { data } = await axios.post("/employe/signup", employe )
            asynccurrentemploye()      
        } catch (error) {
            dispatch(iserror(error.response.data.message))
        }
}


export const asyncinemploye = (employe) => async(dispatch,getstate) =>{
    try {
        const { data } = await axios.post("/employe/signin" , employe)
        asynccurrentemploye()      
    } catch (error) {
        dispatch(iserror(error.response.data.message))
    }
}



export const asyncsignoutemploye = (employe) => async(dispatch,getstate) =>{
    try {
        const { data } = await axios.get("/employe/signout" , employe)
        dispatch(removeemploye())
    } catch (error) {
        dispatch(iserror(error.response.data.message))
    }
}


export const asyncshowtasks = () => async(dispatch,getstate) =>{
    try {
        const { data } = await axios.post("/employe/read/tasks/"  )
        dispatch(addtasks(data.tasks))
        dispatch(asynccurrentemploye())

    } catch (error) {
        dispatch(iserror(error.response.data.message))
    }
}


export const asynccreatetasks = (task)=>async(dispatch,getState)=>{

    try{
        const {data} = await axios.post("/employe/task/create",task);
        dispatch(asynccurrentemploye());
    }catch(error){
        dispatch(iserror(error.response.data.message))
    }
}



